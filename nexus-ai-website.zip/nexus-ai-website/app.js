const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const hasFinePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

// 1. 实时时钟 (增强数字名片精密感)
function updateClock() {
    const clockEl = document.getElementById('live-clock');
    if (!clockEl) return;
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];
    clockEl.textContent = `UTC+8 ${timeStr}`;
}
setInterval(updateClock, 1000);
updateClock();

// 2. 自定义流体光标（仅限桌面精细指针且未开启减弱动画）
const dot = document.getElementById('cursor-dot');
const ring = document.getElementById('cursor-ring');
let mouseX = window.innerWidth / 2, mouseY = window.innerHeight / 2;
let ringX = mouseX, ringY = mouseY;

if (hasFinePointer && !prefersReducedMotion) {
    window.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        if (dot) {
            dot.style.left = `${mouseX}px`;
            dot.style.top = `${mouseY}px`;
        }
    });

    function animateCursor() {
        ringX += (mouseX - ringX) * 0.15;
        ringY += (mouseY - ringY) * 0.15;
        if (ring) {
            ring.style.left = `${ringX}px`;
            ring.style.top = `${ringY}px`;
        }
        requestAnimationFrame(animateCursor);
    }
    animateCursor();

    document.querySelectorAll('.interactive, a, button, select, input, textarea').forEach(el => {
        el.addEventListener('mouseenter', () => document.body.classList.add('hovering'));
        el.addEventListener('mouseleave', () => document.body.classList.remove('hovering'));
    });
}

// 3. 滚动视差渐显 (Intersection Observer)
if (prefersReducedMotion) {
    document.querySelectorAll('.reveal').forEach(el => el.classList.add('active'));
} else {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}

// 4. 快捷联动与复制功能
function escapeHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function selectIntent(val) {
    const select = document.getElementById('intent-select');
    if (select) select.value = val;
}

function copyText(text, btn) {
    if (!btn) return;
    if (!btn.dataset.originalHtml) {
        btn.dataset.originalHtml = btn.innerHTML;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).catch(() => {});
    }
    btn.innerHTML = `<span class="text-cyanGlow">COPIED // ${escapeHtml(text)}</span>`;
    clearTimeout(btn._copyTimer);
    btn._copyTimer = setTimeout(() => {
        btn.innerHTML = btn.dataset.originalHtml;
    }, 2000);
}

function handleFormSubmit(e) {
    e.preventDefault();
    const btn = document.getElementById('submit-btn');
    if (btn) {
        btn.textContent = 'TRANSMISSION RECEIVED // 信号已送达依然智枢中枢';
        btn.classList.remove('bg-white');
        btn.classList.add('bg-cyanGlow');
    }
    if (e.target && typeof e.target.reset === 'function') {
        e.target.reset();
    }
}

// 5. Three.js 宏大抽象神经星云与引力波场 (支持 prefers-reduced-motion 静态渲染与 WebGL 异常降级)
const canvas = document.getElementById('webgl-canvas');
if (canvas && typeof THREE !== 'undefined') {
    try {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.z = 38;

        const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

        const particleCount = 3200;
        const geometry = new THREE.BufferGeometry();
        const positions = new Float32Array(particleCount * 3);
        const colors = new Float32Array(particleCount * 3);

        const colorCyan = new THREE.Color('#00F0FF');
        const colorViolet = new THREE.Color('#7000FF');
        const colorWhite = new THREE.Color('#E2E8F0');

        for (let i = 0; i < particleCount; i++) {
            const i3 = i * 3;
            const radius = 8 + Math.random() * 28;
            const spinAngle = radius * 0.35;
            const branchAngle = ((i % 3) / 3) * Math.PI * 2;

            const randomX = Math.pow(Math.random(), 3) * (Math.random() < 0.5 ? 1 : -1) * 6;
            const randomY = Math.pow(Math.random(), 3) * (Math.random() < 0.5 ? 1 : -1) * 6;
            const randomZ = Math.pow(Math.random(), 3) * (Math.random() < 0.5 ? 1 : -1) * 6;

            positions[i3] = Math.cos(branchAngle + spinAngle) * radius + randomX;
            positions[i3 + 1] = randomY * 1.5;
            positions[i3 + 2] = Math.sin(branchAngle + spinAngle) * radius + randomZ;

            const mixedColor = colorCyan.clone().lerp(colorViolet, (radius - 8) / 28);
            if (Math.random() > 0.85) mixedColor.lerp(colorWhite, 0.8);

            colors[i3] = mixedColor.r;
            colors[i3 + 1] = mixedColor.g;
            colors[i3 + 2] = mixedColor.b;
        }

        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

        const material = new THREE.PointsMaterial({
            size: 0.14,
            vertexColors: true,
            transparent: true,
            opacity: 0.75,
            blending: THREE.AdditiveBlending
        });

        const particleSystem = new THREE.Points(geometry, material);
        particleSystem.rotation.x = 0.55;
        particleSystem.rotation.z = -0.2;
        scene.add(particleSystem);

        const coreGeo = new THREE.IcosahedronGeometry(5.5, 1);
        const coreMat = new THREE.MeshBasicMaterial({
            color: 0x00F0FF,
            wireframe: true,
            transparent: true,
            opacity: 0.12
        });
        const coreMesh = new THREE.Mesh(coreGeo, coreMat);
        scene.add(coreMesh);

        if (prefersReducedMotion) {
            renderer.render(scene, camera);
        } else {
            let scrollY = 0;
            window.addEventListener('scroll', () => {
                scrollY = window.scrollY;
            }, { passive: true });

            const clock = new THREE.Clock();
            function animate3D() {
                const elapsedTime = clock.getElapsedTime();

                particleSystem.rotation.y = elapsedTime * 0.05 + scrollY * 0.0005;
                particleSystem.rotation.x = 0.55 + Math.sin(elapsedTime * 0.2) * 0.08 + scrollY * 0.0002;

                coreMesh.rotation.y = -elapsedTime * 0.15;
                coreMesh.rotation.x = elapsedTime * 0.1;
                const scale = 1 + Math.sin(elapsedTime * 1.5) * 0.06;
                coreMesh.scale.set(scale, scale, scale);

                const targetX = (mouseX / window.innerWidth - 0.5) * 4;
                const targetY = (mouseY / window.innerHeight - 0.5) * 4;
                camera.position.x += (targetX - camera.position.x) * 0.03;
                camera.position.y += (-targetY - camera.position.y) * 0.03;
                camera.lookAt(scene.position);

                renderer.render(scene, camera);
                requestAnimationFrame(animate3D);
            }
            animate3D();
        }

        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            if (prefersReducedMotion) {
                renderer.render(scene, camera);
            }
        });
    } catch (_) {
        // WebGL 环境不可用时静默回退到深空背景与网格纹理
    }
}
