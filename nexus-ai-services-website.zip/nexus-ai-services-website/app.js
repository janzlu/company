// 0. HTML 转义工具函数（防止表单回显 XSS 注入）
function escapeHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// 1. 移动端菜单开关
const mobileMenuBtn = document.getElementById('mobile-menu-btn');
const mobileMenu = document.getElementById('mobile-menu');
if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', () => {
        const isHidden = mobileMenu.classList.toggle('hidden');
        mobileMenuBtn.setAttribute('aria-expanded', String(!isHidden));
    });
}

// 2. 首屏架构图底部实时滚动日志
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const liveLogs = [
    "正在解析宁波华东仓原材料BOM缺口，已自动触发ERP采购单 #PO-8942...",
    "【一人公司AI矩阵】跨境独立站客服Agent已完成德语询盘解答并生成PayPal账单...",
    "【企业AI+ERP】车间视觉终端识别送货单完毕，已自动核对入库并同步应付账款...",
    "【企业AI+ERP】检测到3号注塑机交期冲突，AI已重新推演最优排产甘特图...",
    "【一人公司AI矩阵】已自动抓取今日行业热点，生成6篇多平台种草图文并完成定时发布..."
];
let logIdx = 0;
if (!prefersReducedMotion) {
    setInterval(() => {
        logIdx = (logIdx + 1) % liveLogs.length;
        const logEl = document.getElementById('live-log-text');
        if (logEl) {
            logEl.style.opacity = '0';
            setTimeout(() => {
                logEl.textContent = liveLogs[logIdx];
                logEl.style.opacity = '1';
            }, 200);
        }
    }, 3800);
}

// 3. 双核产品专区 Tab 切换
function switchProductTab(tab) {
    const panelErp = document.getElementById('panel-erp');
    const panelSolo = document.getElementById('panel-solo');
    const btnErp = document.getElementById('tab-btn-erp');
    const btnSolo = document.getElementById('tab-btn-solo');
    if (!panelErp || !panelSolo || !btnErp || !btnSolo) return;

    if (tab === 'erp') {
        panelErp.classList.remove('hidden');
        panelSolo.classList.add('hidden');
        btnErp.setAttribute('aria-selected', 'true');
        btnSolo.setAttribute('aria-selected', 'false');
        btnErp.className = "px-6 py-3 rounded-xl font-bold text-sm sm:text-base transition-all flex items-center gap-2.5 bg-gradient-to-r from-blue-600 to-cyan-500 text-white shadow-lg";
        btnSolo.className = "px-6 py-3 rounded-xl font-bold text-sm sm:text-base transition-all flex items-center gap-2.5 text-slate-400 hover:text-white";
    } else {
        panelSolo.classList.remove('hidden');
        panelErp.classList.add('hidden');
        btnSolo.setAttribute('aria-selected', 'true');
        btnErp.setAttribute('aria-selected', 'false');
        btnSolo.className = "px-6 py-3 rounded-xl font-bold text-sm sm:text-base transition-all flex items-center gap-2.5 bg-gradient-to-r from-emerald-600 to-teal-500 text-white shadow-lg";
        btnErp.className = "px-6 py-3 rounded-xl font-bold text-sm sm:text-base transition-all flex items-center gap-2.5 text-slate-400 hover:text-white";
    }
}

// 4. 【企业 AI+ERP 沙盒】预设指令数据与交互渲染
const erpDemos = [
    {
        userPrompt: "“下周新接了3000套智能阀门急单，帮我核查华东仓BOM原材料缺口，自动重排车间机台并生成采购申请单。”",
        aiSteps: [
            "已读取 ERP 库存表、在途采购单及 3000套智能阀门 3级 BOM 清单",
            "识别到【304不锈钢密封圈】缺口 1,450 件，【微型步进电机】库存充足",
            "已自动调用历史最优供应商（宁波精工）比价，并重排 2号、4号CNC机台夜班班次"
        ],
        cardTitle: "AI+ERP 自动生成执行单据（待您一键确认）",
        metrics: [
            { label: "预计齐套交期", val: "10月31日 16:00 (提前1.5天)", color: "text-emerald-400" },
            { label: "自动生成采购单", val: "#PO-20261026-09 (¥28,400)", color: "text-cyan-400" },
            { label: "产能负荷率", val: "94.2% (无交期延误风险)", color: "text-amber-400" }
        ],
        actionText: "已同步至车间MES看板与采购部企业微信"
    },
    {
        userPrompt: "“[上传了一张微信拍的褶皱纸质送货单照片] 把这张供应商送来的五金配件入库，核对跟上月采购合同单价有没有出入。”",
        aiSteps: [
            "多模态视觉大模型 OCR 识别手写/印章单据成功（识别准确率 99.9%）",
            "自动匹配 ERP 关联采购合同 #HT-9021，校验全部 12 项物料编码与实收数量",
            "<i class=\"fa-solid fa-triangle-exclamation text-amber-400 mr-1\" aria-hidden=\"true\"></i>价格异常拦截：发现第4项【M8高强螺栓】送货单价 ¥1.25 高于合同约定价 ¥1.10！"
        ],
        cardTitle: "AI 智能审单与入库拦截报告",
        metrics: [
            { label: "正常入库项", val: "11 项物料已自动生成入库单", color: "text-emerald-400" },
            { label: "异常差价拦截", val: "拦截多计金额 ¥1,500.00", color: "text-red-400" },
            { label: "财务应付凭证", val: "已按合同正确价预生成凭证", color: "text-cyan-400" }
        ],
        actionText: "已自动向采购员与供应商发送差价核实通知"
    },
    {
        userPrompt: "“为什么这个月营收涨了20%，但账面净利润反而少了？帮我穿透查一下原因，并把超期未回款的客户列出来催收。”",
        aiSteps: [
            "已跨模块穿透分析：销售订单毛利表 + 车间实际工时损耗 + 物流费用明细",
            "定位核心原因：① 华南区特价促销让利 4.2%；② A款包装纸箱原材料本月中旬涨价 11%",
            "已筛出 4 家超账期 15 天以上客户（合计应收 ¥34.6万），并拟好差异化催款函"
        ],
        cardTitle: "业财一体 AI 经营诊断与催收执行卡",
        metrics: [
            { label: "利润流失主因", val: "辅料涨价未同步更新销售底价", color: "text-amber-400" },
            { label: "逾期应收总额", val: "¥ 346,000 (4家客户)", color: "text-cyan-400" },
            { label: "AI 自动动作", val: "已向对应销售企微派发催收跟进任务", color: "text-emerald-400" }
        ],
        actionText: "已自动锁定逾期超30天客户的ERP新建发货权限"
    }
];

function runErpDemo(index) {
    document.querySelectorAll('.erp-cmd-btn').forEach((btn, i) => {
        if (i === index) {
            btn.className = "erp-cmd-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 transition-all";
        } else {
            btn.className = "erp-cmd-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 text-slate-300 hover:bg-white/10 border border-white/10 transition-all";
        }
    });

    const data = erpDemos[index] || erpDemos[0];
    const container = document.getElementById('erp-sandbox-output');
    if (!container) return;

    container.innerHTML = `
        <div class="flex justify-end">
            <div class="bg-blue-600/30 border border-blue-400/40 text-white rounded-2xl rounded-tr-none px-4 py-3 max-w-xl text-xs sm:text-sm">
                <div class="text-[10px] text-cyan-300 font-semibold mb-1"><i class="fa-solid fa-user-tie mr-1"></i>总经理 / 业务主管指令：</div>
                ${data.userPrompt}
            </div>
        </div>
        <div class="flex items-start gap-3">
            <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shrink-0 mt-1">
                <i class="fa-solid fa-robot text-xs"></i>
            </div>
            <div class="flex-1 space-y-3">
                <div class="p-3 rounded-xl bg-slate-900/90 border border-white/10 text-xs space-y-1.5 font-mono">
                    <div class="text-cyan-400 font-semibold flex items-center gap-2">
                        <i class="fa-solid fa-circle-nodes animate-spin" aria-hidden="true"></i>
                        <span>依然智枢 AI+ERP 引擎已执行以下底层操作：</span>
                    </div>
                    ${data.aiSteps.map(step => `<div class="text-slate-300 pl-4"><i class="fa-solid fa-check text-emerald-400 mr-1.5" aria-hidden="true"></i>${step}</div>`).join('')}
                </div>
                <div class="p-4 rounded-xl bg-gradient-to-br from-slate-900 to-blue-950/50 border border-cyan-500/40">
                    <div class="flex items-center justify-between border-b border-white/10 pb-2.5 mb-3">
                        <span class="text-xs font-bold text-white flex items-center gap-1.5">
                            <i class="fa-solid fa-bolt text-amber-400"></i>${data.cardTitle}
                        </span>
                        <span class="text-[11px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">已打通最后一公里执行</span>
                    </div>
                    <div class="grid sm:grid-cols-3 gap-3">
                        ${data.metrics.map(m => `
                            <div class="p-2.5 rounded-lg bg-black/40 border border-white/5">
                                <div class="text-[11px] text-slate-400">${m.label}</div>
                                <div class="text-xs font-bold ${m.color} mt-0.5">${m.val}</div>
                            </div>
                        `).join('')}
                    </div>
                    <div class="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between text-[11px]">
                        <span class="text-emerald-400"><i class="fa-solid fa-check-circle mr-1"></i>${data.actionText}</span>
                        <span class="text-slate-400">全流程耗时：1.2秒</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// 5. 【一人公司 AI 效率工具】预设工作流模拟
const soloDemos = [
    {
        icon: "fa-earth-americas",
        title: "跨境电商 / 外贸 SOHO 超级个体 24小时自动化流水线",
        desc: "主理人只需负责选品决策，其余获客、多语种询盘跟进、算价、下单履约全部由定制AI数字员工闭环完成：",
        agents: [
            { role: "AI 海外社媒获客专员", time: "08:00 自动执行", task: "抓取TikTok/Instagram欧美热门趋势，自动生成5条本土化英文短视频脚本与独立站SEO文章并发布。", status: "日均自然流询盘 +38条" },
            { role: "AI 多语种销冠客服", time: "7×24h 秒级响应", task: "通过WhatsApp/邮件用英、德、西语同时接待12位海外买家，调用产品库自动发送阶梯报价单与样品链接。", status: "夜间无人值守成交 $4,200" },
            { role: "AI 供应链跟单与记账助理", time: "订单触发即执行", task: "客户付款后，自动向国内工厂下达采购指令、回填国际物流单号，并生成单品净利核算表。", status: "零人工干预自动履约" }
        ]
    },
    {
        icon: "fa-bullseye",
        title: "知识IP / 咨询顾问 / 商业设计师 一人公司放大器",
        desc: "把您一个人的专业大脑复制成10个分身，彻底摆脱“手停口停”的时间出卖模式：",
        agents: [
            { role: "AI 爆款选题与多端内容矩阵", time: "09:00 自动执行", task: "将您的一段3分钟语音观点，自动扩写为公众号深度长文、小红书高颜值图文卡片及视频号口播稿。", status: "全网内容产出效率提升 10倍" },
            { role: "AI 私域诊断与高客单逼单助手", time: "全天候私域接待", task: "新粉加微信后，AI按您的顾问话术自动进行客户需求问卷诊断，筛出高意向客户并预约您的1对1付费咨询。", status: "无效陪聊时间减少 90%" },
            { role: "AI 方案报告与合同法务助理", time: "交付阶段加速", task: "根据客户沟通录音，调用您的历史案例库10分钟生成《定制初版方案PPT大纲》与标准服务合同。", status: "交付产能翻 3倍" }
        ]
    },
    {
        icon: "fa-bag-shopping",
        title: "高客单私域工作室 / 垂直非标定制买手团队",
        desc: "针对非标定制、生鲜特产供应链、软装设计等重服务行业，让1个人轻松维护5000+高净值客户：",
        agents: [
            { role: "AI 客户画像与朋友圈千人千面", time: "智能标签触发", task: "自动分析客户聊天记录中的预算偏好、复购周期与审美风格，每日自动生成针对性的朋友圈文案与私信关怀。", status: "老客复购率提升 65%" },
            { role: "AI 视觉选款与秒级定制报价", time: "客户发图即响应", task: "客户发来参考图，AI秒级在您的数万张档口/工厂图库中检索同款，结合当日原料行情算出精准定制报价。", status: "询单转化率提升 2.8倍" },
            { role: "AI 定制工期盯单管家", time: "全流程节点播报", task: "自动追踪合作工坊生产进度，在打版、质检、顺丰寄出节点自动向客户发送精美进度播报卡。", status: "高端服务体验拉满" }
        ]
    }
];

function runSoloDemo(index) {
    document.querySelectorAll('.solo-cmd-btn').forEach((btn, i) => {
        if (i === index) {
            btn.className = "solo-cmd-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-400/50 transition-all";
        } else {
            btn.className = "solo-cmd-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 text-slate-300 hover:bg-white/10 border border-white/10 transition-all";
        }
    });

    const data = soloDemos[index] || soloDemos[0];
    const container = document.getElementById('solo-sandbox-output');
    if (!container) return;

    container.innerHTML = `
        <div class="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30">
            <div class="text-sm font-bold text-white flex items-center gap-2"><i class="fa-solid ${data.icon} text-emerald-400" aria-hidden="true"></i><span>${data.title}</span></div>
            <div class="text-xs text-slate-300 mt-1">${data.desc}</div>
        </div>
        <div class="space-y-3">
            ${data.agents.map((ag, idx) => `
                <div class="p-3.5 rounded-xl bg-slate-900/90 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div class="space-y-1">
                        <div class="flex items-center gap-2">
                            <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[11px] font-bold">数字员工 0${idx + 1}</span>
                            <span class="text-xs font-bold text-white">${ag.role}</span>
                            <span class="text-[11px] text-slate-400 font-mono">· ${ag.time}</span>
                        </div>
                        <p class="text-xs text-slate-300 leading-relaxed">${ag.task}</p>
                    </div>
                    <div class="shrink-0 sm:text-right">
                        <span class="inline-block px-2.5 py-1 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold">
                            ${ag.status}
                        </span>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

// 6. ROI 降本增效测算器逻辑
function setRoiType(type) {
    const btnSme = document.getElementById('roi-type-sme');
    const btnSolo = document.getElementById('roi-type-solo');
    const staffSlider = document.getElementById('roi-staff-slider');
    const hoursSlider = document.getElementById('roi-hours-slider');
    const salarySlider = document.getElementById('roi-salary-slider');
    if (!btnSme || !btnSolo || !staffSlider || !hoursSlider || !salarySlider) return;

    if (type === 'sme') {
        btnSme.className = "p-3.5 rounded-xl border border-cyan-400 bg-cyan-500/20 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all";
        btnSolo.className = "p-3.5 rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white font-bold text-sm flex items-center justify-center gap-2 transition-all";
        staffSlider.value = 25;
        hoursSlider.value = 3.5;
        salarySlider.value = 8500;
    } else {
        btnSolo.className = "p-3.5 rounded-xl border border-emerald-400 bg-emerald-500/20 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all";
        btnSme.className = "p-3.5 rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white font-bold text-sm flex items-center justify-center gap-2 transition-all";
        staffSlider.value = 2;
        hoursSlider.value = 5.0;
        salarySlider.value = 12000;
    }
    calculateROI();
}

function calculateROI() {
    const staffEl = document.getElementById('roi-staff-slider');
    const hoursEl = document.getElementById('roi-hours-slider');
    const salaryEl = document.getElementById('roi-salary-slider');
    const staffValEl = document.getElementById('roi-staff-val');
    const hoursValEl = document.getElementById('roi-hours-val');
    const salaryValEl = document.getElementById('roi-salary-val');
    const timeSavedEl = document.getElementById('roi-time-saved');
    const moneySavedEl = document.getElementById('roi-money-saved');
    const eqStaffEl = document.getElementById('roi-eq-staff');
    const recEl = document.getElementById('roi-recommendation');
    const badgeEl = document.getElementById('roi-badge');
    if (!staffEl || !hoursEl || !salaryEl || !staffValEl || !hoursValEl || !salaryValEl || !timeSavedEl || !moneySavedEl || !eqStaffEl || !recEl || !badgeEl) return;

    const staff = parseInt(staffEl.value, 10);
    const hours = parseFloat(hoursEl.value);
    const salary = parseInt(salaryEl.value, 10);

    staffValEl.textContent = staff;
    hoursValEl.textContent = hours.toFixed(1);
    salaryValEl.textContent = salary.toLocaleString();

    const annualHoursSaved = Math.round(staff * hours * 250 * 0.75);
    const hourlyCost = salary / (21.75 * 8);
    const annualMoneySaved = Math.round(annualHoursSaved * hourlyCost * 1.15);
    const eqStaff = Math.max(1, (annualHoursSaved / 2000).toFixed(1));

    timeSavedEl.textContent = annualHoursSaved.toLocaleString();
    moneySavedEl.textContent = annualMoneySaved.toLocaleString();
    eqStaffEl.textContent = eqStaff;

    if (staff <= 8) {
        badgeEl.textContent = "一人公司/轻团队高人效方案";
        recEl.textContent = "【一人公司 AI 超级效率矩阵定制版】为您配置 24h 智能销冠客服 + 全自动内容获客工作流 + 自动跟单记账助理，无需扩招员工即可实现业绩倍增。";
    } else if (staff <= 40) {
        badgeEl.textContent = "预计回本周期 < 2.5个月";
        recEl.textContent = "【成长型企业 AI+ERP 核心模块定制】重点打通微信/纸质单据自动审单入库、智能库存预警与业财一体核算，支持旧系统无损升级，彻底解放跟单与财务人员。";
    } else {
        badgeEl.textContent = "规模化企业深度赋能方案";
        recEl.textContent = "【企业级全链路 AI+ERP 私有化旗舰版】深度定制智能排产算法、供应链协同Agent、管理层自然语言BI驾驶舱及私有大模型本地安全部署，免费培养1名内部AI管理员。";
    }
}

// 7. 底部咨询表单提交交互
function submitConsultForm(e) {
    e.preventDefault();
    const nameEl = document.getElementById('form-name');
    const phoneEl = document.getElementById('form-phone');
    const productEl = document.getElementById('form-product');
    const formEl = document.getElementById('consult-form');
    const successBox = document.getElementById('form-success-box');
    const detailText = document.getElementById('form-success-detail');
    if (!nameEl || !phoneEl || !productEl || !formEl || !successBox || !detailText) return;

    const name = escapeHtml(nameEl.value);
    const phone = escapeHtml(phoneEl.value);
    const product = escapeHtml(productEl.value);

    formEl.classList.add('hidden');
    detailText.innerHTML = `尊敬的 <strong>${name}</strong>，我们已收到您关于 <span class="text-cyan-400 font-semibold">【${product}】</span> 的定制诊断需求。<br/>宁波依然网络科技（依然智枢）林经理与首席AI架构师将在 2 小时内通过电话/微信（<strong>${phone}</strong>）与您取得联系，您也可直接拨打专线 <strong>159-6841-4820</strong>。`;
    successBox.classList.remove('hidden');
}

function resetConsultForm() {
    const formEl = document.getElementById('consult-form');
    const successBox = document.getElementById('form-success-box');
    if (!formEl || !successBox) return;
    formEl.reset();
    formEl.classList.remove('hidden');
    successBox.classList.add('hidden');
}

// 页面初始化加载默认沙盒与ROI计算
window.addEventListener('DOMContentLoaded', () => {
    runErpDemo(0);
    runSoloDemo(0);
    calculateROI();
});
